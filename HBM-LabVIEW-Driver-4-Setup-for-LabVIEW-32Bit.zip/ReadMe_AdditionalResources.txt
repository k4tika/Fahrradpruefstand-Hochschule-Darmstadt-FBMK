The technical support team helps customers in many ways. Meanwhile there are various
VIs available, that were provided to support certain customer requests. Since these VIs
were created for very special demands, they are not installed under the user.lib but are
available as an extra zip file which you can find in the same directory as the setup of the
HBM LabVIEW Driver.
These VIs can be used to get a further understanding of the usage of the underlying HBM
Common API and might already contain the solution or at least a hint to solve specific
problems, that are not covered by the VIs that are included in the setup of the HBM
LabVIEW Driver.